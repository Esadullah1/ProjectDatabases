﻿using System;

namespace SomerenModel
{
    public class ActivityStudents
    {

        public string ActiviyId { get; set; }
        public int StudentID { get; set; }
    }
}
