﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class registeren
    {
        public string userName { get; set; }
        public string passWord { get; set; }
    }
}
